package comp1206.sushi.server;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.server.ServerWindow;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;

import java.awt.event.*;
import java.util.List;


class RestockAmountListener implements ActionListener {

    JButton enter;
    List<Dish> dishes;
    JTable table1;
    ServerInterface server;
    JTextField restockAmount;
    JTextField restockThreshold;
    String dishName;

    //when edit button is pressed on restock levels, open new window, take input from user and
    public RestockAmountListener(JButton enter, JTable table1, ServerInterface server, List<Dish> dishes, JTextField restockAmount, JTextField restockThreshold){
		this.enter = enter;
		this.table1 = table1;
		//this.table2 = table2;
		this.server = server;
		this.dishes = dishes;
		this.restockAmount = restockAmount;
		this.restockThreshold = restockThreshold;
    }
    
    //in order to remove the previous dish from the server, add new dish, and delete the old dish
    public void actionPerformed(ActionEvent e){
    	
    	if(e.getSource() == enter) {
    	
	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();

	        if (table1.getSelectedRow() != -1) {
	            String restockAmountValue = restockAmount.getText(); 
	            String restockThresholdValue = restockThreshold.getText();
	            List<Dish> dishes = server.getDishes();
	            int column = 0;

	            int row = table1.getSelectedRow();
	            String dishName = model.getValueAt(row, column).toString();
            
	            Dish dish = findDishByName(dishes, dishName);
	            
					
	           /*if (e.getSource() == editButton) {
	                selectedRow = uTable.getSelectedRow();
	                if (selectedRow >= 0) {
	                    editUser(selectedRow);
	                } else {
	                    JOptionPane.showMessageDialog(null, "Select a row");
	                }
	            }*/

	           model.setValueAt(dish.getName(), row, 0);
	           model.setValueAt(dish.getDescription(), row, 1);
	           model.setValueAt(dish.getPrice(), row, 2);
	           model.setValueAt(Integer.valueOf(restockAmountValue), row, 3);
	           model.setValueAt(Integer.valueOf(restockThresholdValue), row, 4);
	           
	           // model.addRow(new Object[] {dish.getName(), dish.getDescription(), dish.getPrice(), Integer.valueOf(restockAmountValue), Integer.valueOf(restockThresholdValue)});
        		/*try {
        			server.removeDish(dish);
				} catch (UnableToDeleteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} */
        		//model.removeRow(row);

	            //server.addDish(dish.getName(), dish.getDescription(), dish.getPrice(), Integer.valueOf(restockAmountValue), Integer.valueOf(restockThresholdValue));
        		server.setRestockLevels(dish, Integer.valueOf(restockAmountValue), Integer.valueOf(restockThresholdValue));


	            

        		
	            
	        }
    	}

		
    }
  
	     private static Dish findDishByName(List<Dish> dishes, String dishName)
	     {
            for(Dish dish: dishes) {
            	if(dishName.equals(dish.getName())) {
            		return dish;
            	}
            }
            
            throw new RuntimeException("No dish with given name");
	     }
    }
        /*model.setValueAt(restockAmountValue, row1, column1);
        model.setValueAt(restockThresholdValue, row1, column2); */
