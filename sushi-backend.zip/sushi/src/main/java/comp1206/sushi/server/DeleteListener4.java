package comp1206.sushi.server;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Staff;
import comp1206.sushi.common.Supplier;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;
import java.awt.event.*;
import java.util.List;

	class DeleteListener4 implements ActionListener {

	    JButton b1;
	    JTable table1;
	    List<Staff> staff;
	    ServerInterface server;

	    public DeleteListener4(JButton b1,JTable table1,ServerInterface server, List<Staff> staff){
			this.b1 = b1;
			this.table1 = table1;
			this.server = server;
			this.staff = staff;
	    }
	    
	    public void actionPerformed(ActionEvent e) {
	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();
	    	
	        if (table1.getSelectedRow() != -1) {
 
	            List<Staff> staffs = server.getStaff();
	            int column = 0;
	            int row = table1.getSelectedRow();
	            String staffName = model.getValueAt(row, column).toString();
	            
	            Staff staff = findStaffByName(staffs, staffName);

        		try {
        			server.removeStaff(staff);
				} catch (UnableToDeleteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        		
	            model.removeRow(table1.getSelectedRow()); 
	        }
	     }
	        
	     private static Staff findStaffByName(List<Staff> staffs, String staffName)
	     {
            for(Staff staff: staffs) {
            	if(staffName.equals(staff.getName())) {
            		return staff;
            	}
            }
            throw new RuntimeException("No staff with given name");
	     } 

}
