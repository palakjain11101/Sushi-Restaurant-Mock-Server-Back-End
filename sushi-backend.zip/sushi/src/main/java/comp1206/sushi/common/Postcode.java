package comp1206.sushi.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import comp1206.sushi.common.Postcode;

public class Postcode extends Model {

	private String name;
	private Map<String,Double> latLong;
	private Number distance;
	String lat;
	int longCoordInt = 0;
	int latCoordInt = 0;

	public Postcode(String code) {
		this.name = code;
		calculateLatLong();
		this.distance = Integer.valueOf(0);
	}
	
	public Postcode(String code, Restaurant restaurant) {
		this.name = code;
		calculateLatLong();
		calculateDistance(restaurant);
	}
	
	@Override
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Number getDistance() {
		return this.distance;
	}

	public Map<String,Double> getLatLong() {
		try {
			getPostcode(name);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return this.latLong;
	}
	
	protected void calculateDistance(Restaurant restaurant) {
		//This function needs implementing
		Postcode destination = restaurant.getLocation();
		Map<String, Double> restLoc = destination.getLatLong();
		Map<String, Double> postLoc = getLatLong();
		this.distance = distance(postLoc.get("lat"),restLoc.get("lat"),postLoc.get("lon"),restLoc.get("lon"),0,0);
	}
	
	protected void calculateLatLong() {
		//This function needs implementing
		
		this.latLong = new HashMap<String,Double>();
		this.distance = new Integer(0);
	}
	
	private String getPostcode(String postcode) throws IOException{
		String postcodeWeb;
    	postcodeWeb = postcode.substring(0,4) + "%20" + postcode.substring(5,8);
    	URL urlForGetRequest = new URL("https://www.southampton.ac.uk/~ob1a12/postcode/postcode.php?postcode=" + postcodeWeb);
    	String readLine  = null; 
    	HttpURLConnection connection = (HttpURLConnection) urlForGetRequest.openConnection();
    	connection.setRequestMethod("GET");
    	int responseCode = connection.getResponseCode();
    	if (responseCode == HttpURLConnection.HTTP_OK){
    		BufferedReader in = new BufferedReader(
    		new InputStreamReader(connection.getInputStream()));
    		StringBuffer response = new StringBuffer();
    		
    		while((readLine = in.readLine()) != null){
    			response.append(readLine);
    		}
    		
    		in.close();
    		lat =response.toString();
    		getLatitude();
    		getLongitude();
    		return lat;
    	}
    	else{
    		return "Not working";
    	}
    
	}
	
	public Double getLongitude(){	
    		double longDouble=0;
    		String postcodeLong1= null;
    		Double longDoubleObj = 0.0;
    		

	    	postcodeLong1 = lat.substring(lat.indexOf("long\":\"") + 7,lat.indexOf("long\":\"")+24);
		    		
		    longDouble = Double.parseDouble(postcodeLong1);
		    		
		    longDoubleObj = (Double)longDouble;
		    	

    		System.out.println(longDoubleObj);
    		latLong.put("lon", longDoubleObj);
    		return longDoubleObj;

    }
	
	public Double getLatitude(){
		Double latDoubleObj = 0.0;
		double latDouble;
		String postcodeLat1;
		
    	postcodeLat1 = lat.substring(lat.indexOf("lat\":\"") + 6,lat.indexOf("lat\":\"")+24);
	    		
    	latDouble = Double.parseDouble(postcodeLat1);
	    latDoubleObj = (Double)latDouble;

		System.out.println(latDoubleObj);
		latLong.put("lat", latDoubleObj);
		return latDoubleObj;
	}

	
	public static double distance(double lat1, double lat2, double lon1,
	        double lon2, double el1, double el2) {

	    final int R = 6371; // Radius of the earth

	    double latDistance = Math.toRadians(lat2 - lat1);
	    double lonDistance = Math.toRadians(lon2 - lon1);
	    double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
	            + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
	            * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
	    double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
	    double distance = R * c * 1000; // convert to meters

	    double height = el1 - el2;

	    distance = Math.pow(distance, 2) + Math.pow(height, 2);
	    
	    DecimalFormat numberFormat = new DecimalFormat("#.000");
	    
	   // System.out.println(numberFormat.format(number));
	    Double distance1 = (Math.sqrt(distance))/1000;
	    String distance2 = numberFormat.format(distance1);
	    Double distance3 = Double.parseDouble(distance2); 
	    return distance3;


	}
}
