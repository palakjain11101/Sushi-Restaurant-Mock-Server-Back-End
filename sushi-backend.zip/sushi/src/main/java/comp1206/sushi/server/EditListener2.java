
	package comp1206.sushi.server;

	import java.awt.*;
	import javax.swing.*;
	import javax.swing.table.DefaultTableModel;
	import comp1206.sushi.common.Ingredient;
	import java.awt.event.*;
	import java.util.List;
	
	class EditListener2 implements ActionListener {

	    JButton b1;
	    JTable table1;
	    ServerInterface server;
	    String restockAmount;
	    String restockThreshold;
	    List<Ingredient> ingredients;

	    //when edit button is pressed on restock levels, open new window, take input from user and
	    public EditListener2(JButton b1, JTable table1, ServerInterface server,  List<Ingredient> ingredients){
			this.b1 = b1;
			this.table1 = table1;
			this.server = server;
			this.ingredients = ingredients;
	    }


	    public void actionPerformed(ActionEvent e){	
	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();
		    if(e.getSource() == b1){
		            JFrame frame = new JFrame("Editing Ingredients");
		            frame.setSize(350, 250);

		            frame.setLocationRelativeTo(null);  
	                
		            
	                JPanel panel = new JPanel();
	                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
	                
	                JPanel inputPanel = new JPanel();
	                inputPanel.setLayout(new GridLayout(4,2));
	                
	                JLabel blank = new JLabel("   ");
	                JLabel blank3 = new JLabel("   ");

	                inputPanel.add(blank);
	                inputPanel.add(blank3);
	                
	                
	             
	                JLabel restockAmountLabel = new JLabel("   Restock Amount:");
	                JTextField restockAmountField = new JTextField(20);
	                
	                JLabel restockThresholdLabel = new JLabel("   Restock Threshold:");
	                JTextField restockThresholdField = new JTextField(20);
	                
	                inputPanel.add(restockAmountLabel);
	                inputPanel.add(restockAmountField);
	                inputPanel.add(restockThresholdLabel);
	                inputPanel.add(restockThresholdField);
	                JLabel blank1 = new JLabel("   ");
	                inputPanel.add(blank1);

	                
	                panel.add(inputPanel);
	                
	                JPanel enterPanel = new JPanel();
	                JButton Enter = new JButton("Enter");
	                enterPanel.add(Enter);
	                panel.add(enterPanel, Component.CENTER_ALIGNMENT);

	                
	                
	        		RestockAmountListener1 RestockAmountListenerB = new RestockAmountListener1(Enter, table1, server, ingredients, restockAmountField, restockThresholdField);
	        		Enter.addActionListener(RestockAmountListenerB);
	        		restockAmountField.addActionListener(RestockAmountListenerB);
	        		restockThresholdField.addActionListener(RestockAmountListenerB);
		   
	                
	                frame.add(panel);
	                
	                frame.setVisible(true);
	                

	                
	       }
	    
	    }
	}

