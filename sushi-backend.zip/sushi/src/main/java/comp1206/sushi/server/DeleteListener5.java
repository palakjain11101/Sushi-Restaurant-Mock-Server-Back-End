package comp1206.sushi.server;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Drone;
import comp1206.sushi.common.Postcode;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;
import java.awt.event.*;
import java.util.List;

	class DeleteListener5 implements ActionListener {

	    JButton b1;
	    JTable table1;
	    List<Drone> drones;
	    ServerInterface server;

	    public DeleteListener5(JButton b1,JTable table1,ServerInterface server, List<Drone> drones){
			this.b1 = b1;
			this.table1 = table1;
			this.server = server;
			this.drones = drones;
	    }
	    
	    public void actionPerformed(ActionEvent e) {
	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();
	    	
	        if (table1.getSelectedRow() != -1) {
 
	            List<Drone> drones = server.getDrones();
	            int column = 0;
	            int row = table1.getSelectedRow();
	            String droneName = model.getValueAt(row, column).toString();
	            
	            Drone drone = findDroneByName(drones, droneName);

        		try {
        			server.removeDrone(drone);
				} catch (UnableToDeleteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        		
	            model.removeRow(table1.getSelectedRow()); 
	        }
	     }
	        
	     private static Drone findDroneByName(List<Drone> drones, String droneName)
	     { 	 
            for(Drone drone : drones) {
            	if(droneName.equals(drone.getName())) {
            		return drone;
            	}
            }
            throw new RuntimeException("No drone with given name");
	     } 

}