package comp1206.sushi.server;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.common.Supplier;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;

import java.awt.event.*;
import java.util.List;

	class AddListener2 implements ActionListener {
		JButton add;
		JTextField nameF;
		JTextField units;
		JTextField supplier;
		JTextField restockAmount; 
		JTextField restockThreshold;
		JComboBox<String>suppliersComboBox;
		JTable table;
		ServerInterface server;
			
	    public AddListener2(JButton add, JTextField nameF, JTextField units, JComboBox<String>suppliersComboBox, JTextField restockAmount, JTextField restockThreshold, JTable table, ServerInterface server){
			this.add = add;
			this.nameF = nameF;
			this.units = units;
			this.suppliersComboBox = suppliersComboBox;
			this.restockAmount = restockAmount;
			this.restockThreshold = restockThreshold;
			this.table = table;
			this.server = server;
	    }

	    

	    public void actionPerformed(ActionEvent e){	
	    	boolean check = false;
    	    List<Ingredient> ingredients = server.getIngredients();
    		DefaultTableModel model = (DefaultTableModel) table.getModel();
    		String text = restockAmount.getText();
    		String text1 = restockThreshold.getText();
    		String text2 = units.getText();
    		
    		
	    	if(e.getSource() == add){
	    		
	            for(Ingredient ingredient: ingredients) {
	            	if(nameF.getText().equals(ingredient.getName())) {
	            		check = true;
		    	    	JFrame frame = new JFrame("Invalid data");
		    	    	
		    			//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			            frame.setSize(350, 100);
			            JPanel panel1 = new JPanel();
			            JLabel label = new JLabel("Data entered is invalid. This ingredient is already in the system.");
			            //frame.add(panel1);
			            panel1.add(label);
			            frame.add(panel1);
			            frame.setVisible(true);
			            frame.setLocationRelativeTo(null);
	            	}
	            }
	    		
	    		if(nameF.getText().equals("")||units.getText().equals("")|| suppliersComboBox.getSelectedItem().equals("") || restockAmount.getText().equals("") || restockThreshold.getText().equals("")) {

	    	    	JFrame frame = new JFrame("Invalid data");
	    	    	
	    			//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		            frame.setSize(350, 100);
		            JPanel panel1 = new JPanel();
		            JLabel label = new JLabel("Data entered is invalid. Please enter all fields.");
		            //frame.add(panel1);
		            panel1.add(label);
		            frame.add(panel1);
		            frame.setVisible(true);
		            frame.setLocationRelativeTo(null);
	    		}
	    		
	    		
	    		else {
					   if(check == false) {
						   if (isNumeric(text) && isNumeric(text1)) {
							   if (isNumeric(text2)){
					    	    	JFrame frame = new JFrame("Invalid data");
						            frame.setSize(450, 100);
						            JPanel panel1 = new JPanel();
						            JLabel label = new JLabel("Data entered is invalid. The Units field must be filled with a word, not a number.");
						            panel1.add(label);
						            frame.add(panel1);
						            frame.setVisible(true);
						            frame.setLocationRelativeTo(null); 
							   }
							   else {
								   model.addRow(new Object[]{nameF.getText(), units.getText(), suppliersComboBox.getSelectedItem(), restockAmount.getText(), restockThreshold.getText()}); 	  
								   server.addIngredient(nameF.getText(), units.getText(), (Supplier) suppliersComboBox.getSelectedItem(), Integer.valueOf(restockAmount.getText()), Integer.valueOf(restockThreshold.getText()));
							   }
							}
						   
						   else {
				    	    	JFrame frame = new JFrame("Invalid data");
					            frame.setSize(450, 100);
					            JPanel panel1 = new JPanel();
					            JLabel label = new JLabel("Data entered is invalid. The Restock fields must be filled with a number.");
					            panel1.add(label);
					            frame.add(panel1);
					            frame.setVisible(true);
					            frame.setLocationRelativeTo(null); 
						   }
					   }
	    		}
					   
	    		
	    	}
	    		
	     }
	    	
		    public static boolean isNumeric(String strNum) {
		        try {
		            double d = Double.parseDouble(strNum);
		        } catch (NumberFormatException | NullPointerException nfe) {
		            return false;
		        }
		        return true;
		    }
		    


}


   