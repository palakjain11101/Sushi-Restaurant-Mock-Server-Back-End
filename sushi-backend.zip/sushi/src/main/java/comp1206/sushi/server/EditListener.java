package comp1206.sushi.server;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.common.Supplier;
import comp1206.sushi.server.ServerWindow;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;

import java.awt.event.*;
import java.util.List;
import java.util.Map;


class EditListener implements ActionListener {

    JButton b1;
    List<Dish> dishes;
    JTable table1;
    JTable table2;
    ServerInterface server;
    String restockAmount;
    String restockThreshold;
    List<Ingredient> ingredients;

    //when edit button is pressed on restock levels, open new window, take input from user and
    public EditListener(JButton b1, JTable table1, ServerInterface server, List<Dish> dishes, List<Ingredient> ingredients){
		this.b1 = b1;
		this.table1 = table1;
		this.server = server;
		this.dishes = dishes;
		this.ingredients = ingredients;
    }


    public void actionPerformed(ActionEvent e){	
    	DefaultTableModel model = (DefaultTableModel) table1.getModel();
	    if(e.getSource() == b1){
	    	
	    	JFrame frame = new JFrame("Editing Dishes");
            frame.setSize(400, 500);
            frame.setLocationRelativeTo(null);  
            
            
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            
            JPanel inputPanel = new JPanel();
            inputPanel.setLayout(new GridLayout(4,2));
       
            JLabel blank = new JLabel("   ");
            JLabel blank3 = new JLabel("   ");
            inputPanel.add(blank);
            inputPanel.add(blank3);
         
            JLabel restockAmountLabel = new JLabel("   Restock Amount:");
            JTextField restockAmountField = new JTextField(20);
            JLabel restockThresholdLabel = new JLabel("   Restock Threshold:");
            JTextField restockThresholdField = new JTextField(20);
            
            inputPanel.add(restockAmountLabel);
            inputPanel.add(restockAmountField);
            inputPanel.add(restockThresholdLabel);
            inputPanel.add(restockThresholdField);
            
            panel.add(inputPanel);
            
            JPanel enterPanel = new JPanel();
            JButton Enter = new JButton("Enter");
            enterPanel.add(Enter);
            panel.add(enterPanel, Component.CENTER_ALIGNMENT);
            
            
            JFrame frame1 = new JFrame("Editing Recipes");
            frame1.setSize(400, 500);
            frame1.setLocationRelativeTo(null);  
            
            JPanel panel1 = new JPanel();
            panel1.setLayout(new BoxLayout(panel1, BoxLayout.Y_AXIS));

            JLabel blank1 = new JLabel("   ");
            
            
            JPanel ingredientsPanel = new JPanel();
            ingredientsPanel.setLayout(new BoxLayout(ingredientsPanel, BoxLayout.Y_AXIS));
            
            ingredientsPanel.add(blank1);
            int row = table1.getSelectedRow();
            
            Dish currentDish = dishes.get(row);
            
            Map<Ingredient, Number> recipe = currentDish.getRecipe();
            
            Object[] columnNames1 = {"Ingredient", "Number of Ingredients"};
            DefaultTableModel model1 = new DefaultTableModel(columnNames1, 0);
            
            JTable table2 = new JTable(model1);
            
            for (Map.Entry<Ingredient, Number> entry : recipe.entrySet()) {
            	model1.addRow(new Object[] { entry.getKey(), entry.getValue() });
            }
            

            ingredientsPanel.add(new JScrollPane(table2));
            panel1.add(ingredientsPanel);
            
            
            JPanel inputPanel1 = new JPanel(new GridLayout(3,2));
            
            JLabel ingredientLabel = new JLabel("  Ingredient:");
            
           
            

            
            List<Ingredient> ingredients = server.getIngredients();
            
            DefaultComboBoxModel modelComboBox = new DefaultComboBoxModel(ingredients.toArray());
            JComboBox<String> ingredientsComboBox = new JComboBox<String>(modelComboBox);
         
            inputPanel1.add(ingredientLabel);

        	inputPanel1.add(ingredientsComboBox);
            
            JLabel ingredientNumberLabel = new JLabel("  Ingredient Number:");
            JTextField ingredientNumberField = new JTextField();
            inputPanel1.add(ingredientNumberLabel);
            inputPanel1.add(ingredientNumberField);
            panel1.add(inputPanel1);
            
            JPanel ingredientsPanelEdit = new JPanel(new FlowLayout());
            JButton add = new JButton("Add Ingredient");
            JButton delete = new JButton("Delete Ingredient");
            ingredientsPanelEdit.add(add);
            ingredientsPanelEdit.add(delete);
            panel1.add(ingredientsPanelEdit);
            
            
            
            
            
            
            
            
            	
                
                
                
                
                
                
                

                
                
        		AddListener1 AddListenerB = new AddListener1(add, delete, ingredientsComboBox, ingredientNumberField, server, dishes, table1, table2, recipe, ingredients);
        		add.addActionListener(AddListenerB);
        		delete.addActionListener(AddListenerB);
        		ingredientsComboBox.addActionListener(AddListenerB);
        		ingredientNumberField.addActionListener(AddListenerB);
        		
        		
                
        		RestockAmountListener RestockAmountListenerA = new RestockAmountListener(Enter, table1, server, dishes, restockAmountField, restockThresholdField);
        		Enter.addActionListener(RestockAmountListenerA);
        		restockAmountField.addActionListener(RestockAmountListenerA);
        		restockThresholdField.addActionListener(RestockAmountListenerA);
	   
                
                frame.add(panel);
                frame1.add(panel1);
                
                frame.setVisible(true);
                frame1.setVisible(true);
                

                
       }
    
    }
    

}
        