package comp1206.sushi.server;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.server.ServerWindow;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;

import java.awt.event.*;
import java.util.List;


class RestockAmountListener1 implements ActionListener {

    JButton enter;
    List<Ingredient> ingredients;
    JTable table1;
    ServerInterface server;
    JTextField restockAmount;
    JTextField restockThreshold;
    String dishName;

    //when edit button is pressed on restock levels, open new window, take input from user and
    public RestockAmountListener1(JButton enter, JTable table1, ServerInterface server, List<Ingredient> ingredients, JTextField restockAmount, JTextField restockThreshold){
		this.enter = enter;
		this.table1 = table1;
		this.server = server;
		this.ingredients = ingredients;
		this.restockAmount = restockAmount;
		this.restockThreshold = restockThreshold;
    }
    
    //in order to remove the previous dish from the server, add new dish, and delete the old dish
    public void actionPerformed(ActionEvent e){
    	
    	if(e.getSource() == enter) {
    	
	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();

	        if (table1.getSelectedRow() != -1) {
	            String restockAmountValue = restockAmount.getText(); 
	            String restockThresholdValue = restockThreshold.getText();
	            List<Ingredient> ingredients = server.getIngredients();
	            int column = 0;

	            int row = table1.getSelectedRow();
	            String ingredientName = model.getValueAt(row, column).toString();
            
	            Ingredient ingredient = findIngredientByName(ingredients, ingredientName);

	          
					

	            model.addRow(new Object[] {ingredient.getName(), ingredient.getUnit(), ingredient.getSupplier(), Integer.valueOf(restockAmountValue), Integer.valueOf(restockThresholdValue)});
        		/*try {
        			server.removeIngredient(ingredient);
				} catch (UnableToDeleteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} */
        		model.removeRow(row);
        		server.setRestockLevels(ingredient, Integer.valueOf(restockAmountValue), Integer.valueOf(restockThresholdValue));

	            //server.addIngredient(ingredient.getName(), ingredient.getUnit(), ingredient.getSupplier(), Integer.valueOf(restockAmountValue), Integer.valueOf(restockThresholdValue));

	        }
	        
    	}

		
    }
    private static Ingredient findIngredientByName(List<Ingredient> ingredients, String ingredientName)
    {
       for(Ingredient ingredient: ingredients) {
       	if(ingredientName.equals(ingredient.getName())) {
       		return ingredient;
       	}
       }
       
       throw new RuntimeException("No ingredient with given name");
    }
}