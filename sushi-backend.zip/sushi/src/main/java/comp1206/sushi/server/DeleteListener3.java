package comp1206.sushi.server;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Supplier;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;
import java.awt.event.*;
import java.util.List;

	class DeleteListener3 implements ActionListener {

	    JButton b1;
	    JTable table1;
	    List<Supplier> suppliers;
	    ServerInterface server;
	    JComboBox<String> suppliersComboBox;

	    public DeleteListener3(JButton b1,JTable table1,ServerInterface server, List<Supplier> suppliers, JComboBox<String> suppliersComboBox){
			this.b1 = b1;
			this.table1 = table1;
			this.server = server;
			this.suppliers = suppliers;
			this.suppliersComboBox = suppliersComboBox;
	    }
	    
	    public void actionPerformed(ActionEvent e) {

	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();

	        if (table1.getSelectedRow() != -1) {
 
	            List<Supplier> suppliers = server.getSuppliers();
	            int column = 0;
	            int row = table1.getSelectedRow();
	            String supplierName = model.getValueAt(row, column).toString();
	            
	            Supplier supplier = findSupplierByName(suppliers, supplierName);

        		try {
        			server.removeSupplier(supplier);
				} catch (UnableToDeleteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        		
	            model.removeRow(table1.getSelectedRow()); 
	            suppliersComboBox.removeItem(supplier);
	        }
	     }
	        
	     private static Supplier findSupplierByName(List<Supplier> suppliers, String supplierName)
	     {
            for(Supplier supplier: suppliers) {
            	if(supplierName.equals(supplier.getName())) {
            		return supplier;
            	}
            }
            throw new RuntimeException("No supplier with given name");
	     } 

}


   

