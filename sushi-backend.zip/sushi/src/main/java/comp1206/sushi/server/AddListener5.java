package comp1206.sushi.server;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Drone;
import comp1206.sushi.common.Postcode;
import comp1206.sushi.common.Supplier;
import comp1206.sushi.server.ServerWindow;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;

import java.awt.event.*;
import java.util.List;

	class AddListener5 implements ActionListener {

	    JButton b1;
	    JTextField t1;
	    JTextField t3;
	    JTextField t2;
	    JTextField t4;
	    JTextField t5;
	    JTextField t6;
	    JTextField t7;
	    JTable table1;
	    ServerInterface server;
	    boolean check;
	    

	    public AddListener5(JButton b1, JTextField t1, JTextField t2, JTextField t3, JTextField t4, JTextField t5, JTextField t6, JTextField t7, JTable table1, ServerInterface server){
			this.b1 = b1;
			this.t1 = t1;
			this.t2 = t2;
			this.t3 = t3;
			this.t4 = t4;
			this.t5 = t5;
			this.t6 = t6;
			this.t7 = t7;
			this.table1 = table1;
			this.server = server;
	    }
	    


	    public void actionPerformed(ActionEvent e){	
    	    List<Drone> drones = server.getDrones();
    		DefaultTableModel model = (DefaultTableModel) table1.getModel();
    		String text = t2.getText();
    		String text1 = t4.getText();
    		String text2 = t5.getText();
    		
    		
	    	if(e.getSource() == b1){
	    		for(Drone drone: drones) {
	            	if(t1.getText().equals(drone.getName())) {
	            		check = true;
		    	    	JFrame frame = new JFrame("Invalid data");
		    	    	
		    			//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			            frame.setSize(350, 100);
			            JPanel panel1 = new JPanel();
			            JLabel label = new JLabel("Data entered is invalid. This drone is already in the system.");
			            //frame.add(panel1);
			            panel1.add(label);
			            frame.add(panel1);
			            frame.setVisible(true);
			            frame.setLocationRelativeTo(null);
	            	}
	            } 
	        }
	    	
	    	if(t1.getText().equals("")||t2.getText().equals("")|| t4.getText().equals("") || t5.getText().equals("")) {

    	    	JFrame frame = new JFrame("Invalid data");
    	    	
    			//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	            frame.setSize(350, 100);
	            JPanel panel1 = new JPanel();
	            JLabel label = new JLabel("Data entered is invalid. Please enter all fields.");
	            //frame.add(panel1);
	            panel1.add(label);
	            frame.add(panel1);
	            frame.setVisible(true);
	            frame.setLocationRelativeTo(null);
    		}
	    	
	    	else {
				   if(check == false) {
					   if (isNumeric(text) && isNumeric(text1) && isNumeric(text2)) {
				    	    model.addRow(new Object[]{t1.getText(), t2.getText(), t3.getText(), t4.getText(), t5.getText(), t6.getText(), t7.getText()}); 	  
				            server.addDrone(Integer.valueOf(t2.getText()));
					   }
					   else {
			    	    	JFrame frame = new JFrame("Invalid data");
				            frame.setSize(450, 100);
				            JPanel panel1 = new JPanel();
				            JLabel label = new JLabel("Data entered is invalid. The Restock fields must be filled with a number.");
				            panel1.add(label);
				            frame.add(panel1);
				            frame.setVisible(true);
				            frame.setLocationRelativeTo(null); 
					   }
				   }
 
				  check = false; 
 		
 	}
 		
  }
 	
	    public static boolean isNumeric(String strNum) {
	        try {
	            double d = Double.parseDouble(strNum);
	        } catch (NumberFormatException | NullPointerException nfe) {
	            return false;
	        }
	        return true;
	    }
	    



}
	    
	        

