package comp1206.sushi.server;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Postcode;
import comp1206.sushi.common.Supplier;
import comp1206.sushi.server.ServerWindow;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;

import java.awt.event.*;
import java.util.List;
import java.util.Map;

	class AddListener7 implements ActionListener {

	    JButton b1;
	    JTextField t1;
	    JTextField t2;
	    JTable table1;
	    ServerInterface server;
		private JComboBox<String> postcodesComboBox;
		boolean check = false;


	    public AddListener7(JButton b1, JTextField t1, JTextField t2, JTable table1, JComboBox<String> postcodesComboBox, ServerInterface server){
			this.b1 = b1;
			this.t1 = t1;
			this.t2 = t2;
			this.table1 = table1;
			this.postcodesComboBox = postcodesComboBox;
			this.server = server;
	    }
	    


	    public void actionPerformed(ActionEvent e){	
	    	List<Postcode> postcodes = server.getPostcodes();
	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();
	    	String text4 = t2.getText();

	    	if(e.getSource() == b1){
	    		for(Postcode postcode: postcodes) {
	            	if(t1.getText().equals(postcode.getName())) {
	            		check = true;
		    	    	JFrame frame = new JFrame("Invalid data");
		    	    	
		    			//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			            frame.setSize(350, 100);
			            JPanel panel1 = new JPanel();
			            JLabel label = new JLabel("Data entered is invalid. This postcode is already in the system.");
			            //frame.add(panel1);
			            panel1.add(label);
			            frame.add(panel1);
			            frame.setVisible(true);
			            frame.setLocationRelativeTo(null);
			            
			            
	            	}
	            	//if new supplier added
	            	
	            }
	    		
	    		if(t1.getText().equals("")) {

	    	    	JFrame frame = new JFrame("Invalid data");
		            frame.setSize(350, 100);
		            JPanel panel1 = new JPanel();
		            JLabel label = new JLabel("Data entered is invalid. Please enter all fields.");
		            panel1.add(label);
		            frame.add(panel1);
		            frame.setVisible(true);
		            frame.setLocationRelativeTo(null);
	    		}
	    		
	    		else {
					   if(check == false) {
					    	Postcode restaurantPostcode = server.getRestaurantPostcode();
					    	
					       // for (Postcode postcode : postcodes) {

						        Postcode postcode = server.addPostcode(t1.getText());
						        postcodesComboBox.addItem(t1.getText());
						        Map<String,Double> latLong = postcode.getLatLong();
						      	Double longitude = latLong.get("lon");//postcode.getLongitude();
						      	Double latitude = latLong.get("lat");//postcode.getLatitude();
						        server.notifyUpdate();
						        
						        //model.addRow(new Object[] {postcode.getName(), postcode.getDistance(), longitude, latitude});
					        //}
					        model.addRow(new Object[]{t1.getText(), postcode.getDistance(), longitude, latitude}); 
				            
					    		//model.addRow(new Object[]{t1.getText()}); 	  

					       }
						   /*else {
				    	    	JFrame frame = new JFrame("Invalid data");
					            frame.setSize(450, 100);
					            JPanel panel1 = new JPanel();
					            JLabel label = new JLabel("Data entered is invalid. The distance field must be filled with an integer value.");
					            panel1.add(label);
					            frame.add(panel1);
					            frame.setVisible(true);
					            frame.setLocationRelativeTo(null); 
						   } */
					   
				   
		    		
		    		check = false;
			    }
	    	}
	}
		    
		    public static boolean isNumeric(String strNum) {
		        try {
		            double d = Double.parseDouble(strNum);
		        } catch (NumberFormatException | NullPointerException nfe) {
		            return false;
		        }
		        return true;
		    }
	 
	    		

	            
	        
	     
	    
	        

}

