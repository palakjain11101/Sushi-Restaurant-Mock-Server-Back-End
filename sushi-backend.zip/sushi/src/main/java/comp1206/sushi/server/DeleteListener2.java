package comp1206.sushi.server;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;
import java.awt.event.*;
import java.util.List;

	class DeleteListener2 implements ActionListener {

	    JButton b1;
	    JTable table1;
	    List<Ingredient> ingredients;
	    ServerInterface server;

	    public DeleteListener2(JButton b1,JTable table1,ServerInterface server, List<Ingredient> ingredients){
			this.b1 = b1;
			this.table1 = table1;
			this.server = server;
			this.ingredients = ingredients;
	    }
	    
	    public void actionPerformed(ActionEvent e) {

	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();

	        if (table1.getSelectedRow() != -1) {
 
	            List<Dish> dishes = server.getDishes();
	            int column = 0;
	            int row = table1.getSelectedRow();
	            String ingredientName = model.getValueAt(row, column).toString();
	            
	            Ingredient ingredient = findIngredientByName(ingredients, ingredientName);

        		try {
        			server.removeIngredient(ingredient);
				} catch (UnableToDeleteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        		
	            model.removeRow(table1.getSelectedRow()); 
	        }
	     }
	        
	     private static Ingredient findIngredientByName(List<Ingredient> ingredients, String ingredientName)
	     {
            for(Ingredient ingredient: ingredients) {
            	if(ingredientName.equals(ingredient.getName())) {
            		return ingredient;
            	}
            }
            
            throw new RuntimeException("No ingredient with given name");
	     } 
	  
	    
	        

}


   

