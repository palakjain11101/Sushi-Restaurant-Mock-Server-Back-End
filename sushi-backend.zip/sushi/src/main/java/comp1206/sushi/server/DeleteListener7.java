package comp1206.sushi.server;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Postcode;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;
import java.awt.event.*;
import java.util.List;

	class DeleteListener7 implements ActionListener {

	    JButton b1;
	    JTable table1;
	    List<Postcode> postcodes;
	    ServerInterface server;

		private JComboBox<String> postcodesComboBox;
		boolean check = false;


	    public DeleteListener7(JButton b1,JTable table1,ServerInterface server, List<Postcode> postcodes, JComboBox<String> postcodesComboBox){
			this.b1 = b1;
			this.table1 = table1;
			this.server = server;
			this.postcodes = postcodes;
			this.postcodesComboBox = postcodesComboBox;
	    }
	    
	    public void actionPerformed(ActionEvent e) {
	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();
	    	
	        if (table1.getSelectedRow() != -1) {
 
	            List<Postcode> postcodes = server.getPostcodes();
	            int column = 0;
	            int row = table1.getSelectedRow();
	            String postcodeName = model.getValueAt(row, column).toString();
	            
	            Postcode postcode = findPostcodeByName(postcodes, postcodeName);

        		try {
        			server.removePostcode(postcode);
				} catch (UnableToDeleteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        		
	            model.removeRow(table1.getSelectedRow()); 
	            postcodesComboBox.removeItem(postcode);
	            //postcodesComboBox.addItem(t1.getText());
	        }
	     }
	        
	     private static Postcode findPostcodeByName(List<Postcode> postcodes, String postcodeName)
	     { 	 
            for(Postcode postcode : postcodes) {
            	if(postcodeName.equals(postcode.getName())) {
            		return postcode;
            	}
            }
            throw new RuntimeException("No postcode with given name");
	     } 

}
