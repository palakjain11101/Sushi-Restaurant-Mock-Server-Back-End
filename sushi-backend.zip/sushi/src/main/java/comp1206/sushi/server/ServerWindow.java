package comp1206.sushi.server;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import comp1206.sushi.mock.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.*;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;
import comp1206.sushi.server.AddListener; 


/**
 * Provides the Sushi Server user interface
 *
 */
public class ServerWindow extends JFrame implements UpdateListener {

	private static final long serialVersionUID = -4661566573959270000L;
	private ServerInterface server;

	
	/**
	 * Create a new server window
	 * @param server instance of server to interact with
	 */
	public ServerWindow(ServerInterface server) {
		super("Sushi Server");
		this.server = server;
		this.setTitle(server.getRestaurantName() + " Server");
		server.addUpdateListener(this);

		
		//Display window
		setSize(850,700);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	
		
		//Start timed updates
		startTimer();
		
		init();
	
	}

	/**
	 * Start the timer which updates the user interface based on the given interval to update all panels
	 */
	public void startTimer() {
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);     
        int timeInterval = 5;
        
        scheduler.scheduleAtFixedRate(() -> refreshAll(), 0, timeInterval, TimeUnit.SECONDS);
	}
	
	/**
	 * Refresh all parts of the server application based on receiving new data, calling the server afresh
	 */
	public void refreshAll() {
		
	}
	
	@Override
	/**
	 * Respond to the model being updated by refreshing all data displays
	 */
	public void updated(UpdateEvent updateEvent) {
		refreshAll();
	}
	
	public void init() {
		Container panel = this.getContentPane(); 
		panel.setLayout(new BorderLayout()); 
		
		JTabbedPane jTabbedPane = new JTabbedPane();
		JPanel jPanelFirst = new JPanel();
		JPanel jPanelSecond = new JPanel();
		JPanel jPanelThird = new JPanel();
		JPanel jPanelFourth = new JPanel();
		JPanel jPanelFifth = new JPanel();
		JPanel jPanelSixth = new JPanel();
		JPanel jPanelSeventh = new JPanel();
		JPanel jPanelEighth = new JPanel();
		JPanel jPanelNineth = new JPanel();
		
		
		
		
		
		
		jPanelFirst.setLayout(new BoxLayout(jPanelFirst, BoxLayout.Y_AXIS));
	    jTabbedPane.addTab("Orders", jPanelFirst);  
	    
	    List<Order>orders = server.getOrders();
	    String[] columnNames = {"Name","Status", "Distance"};
	    
        Order o = orders.get(0);
        MockServer mockServer = new MockServer();
        
        Object[][] data = {{o.getName(), mockServer.getOrderStatus(o), o.getDistance()}};
        JTable table = new JTable(data, columnNames);

        JPanel tablePanel = new JPanel();
        tablePanel.add(table);

        jPanelFirst.add(new JScrollPane(table));
 
     
        JPanel propertiesPanel = new JPanel();
        propertiesPanel.setLayout(new GridLayout(8,2));

	    JLabel nameLabel = new JLabel("Name: ");
	    JTextField nameField = new JTextField(70);
	    propertiesPanel.add(nameLabel);
	    propertiesPanel.add(nameField);
	    
	    JLabel statusLabel = new JLabel("Status: ");
	    JTextField statusField = new JTextField(70);
	    propertiesPanel.add(statusLabel);
	    propertiesPanel.add(statusField);

	    JLabel distanceLabel = new JLabel("Distance: ");
	    SpinnerModel model = new SpinnerNumberModel(10, 0, 50, 1);     
	    JSpinner spinner = new JSpinner(model);
	    propertiesPanel.add(distanceLabel);
	    propertiesPanel.add(spinner);
	    
	    JLabel label15 = new JLabel("");
	    propertiesPanel.add(label15);
	    
	    JLabel label16 = new JLabel("");
	    propertiesPanel.add(label16);
	    
	    JLabel label17 = new JLabel("");
	    propertiesPanel.add(label17);
	    
	    JLabel label18 = new JLabel("");
	    propertiesPanel.add(label18);
	    

	    jPanelFirst.add(propertiesPanel);
	    
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(1,3));

		JButton delete = new JButton("Delete"); 
		JButton edit = new JButton("Edit");
		JButton add = new JButton("Add"); 
		
		bottomPanel.add(delete);
		bottomPanel.add(edit);
		bottomPanel.add(add);
	    jPanelFirst.add(bottomPanel); 
	    
	    

	    
	    
	    
	    
	    
	    jPanelSecond.setLayout(new BoxLayout(jPanelSecond, BoxLayout.Y_AXIS));
	    jTabbedPane.addTab("Dishes", jPanelSecond);

	    List<Dish>dishes = server.getDishes();
	    List<Ingredient>ingredients = server.getIngredients();
	    
        String[] columnNames1 = {"Name","Description", "Price", "Restock Threshold", "RestockAmount"};
	
        DefaultTableModel model1 = new DefaultTableModel(columnNames1, 0);
        JTable table1 = new JTable(model1);
        
        
        for (Dish dish : dishes) {
            model1.addRow(new Object[] {dish.getName(), dish.getDescription(), dish.getPrice(), dish.getRestockAmount(), dish.getRestockThreshold()});
        }
	    

        jPanelSecond.add(new JScrollPane(table1));
	    
        JPanel propertiesPanel1 = new JPanel();
        propertiesPanel1.setLayout(new GridLayout(8,2));

	    JLabel nameLabel1 = new JLabel("Name: ");
	    JTextField nameField1 = new JTextField(70);
	    propertiesPanel1.add(nameLabel1);
	    propertiesPanel1.add(nameField1);
	    
	    JLabel descriptionLabel1 = new JLabel("Description: ");
	    JTextField descriptionField1 = new JTextField(70);
	    propertiesPanel1.add(descriptionLabel1);
	    propertiesPanel1.add(descriptionField1);

	    JLabel priceLabel1 = new JLabel("Price: ");
	    propertiesPanel1.add(priceLabel1);
	    /*SpinnerModel model1 = new SpinnerNumberModel(10, 0, 50, 1); 
	    JSpinner spinner1 = new JSpinner(model1);
	    propertiesPanel1.add(spinner1); */
	    JTextField priceField1 = new JTextField(70);
	    propertiesPanel1.add(priceField1);
	    
	    JLabel restockThresholdLabel1 = new JLabel("Restock Threshold: ");
	    /*SpinnerModel model2 = new SpinnerNumberModel(10, 0, 50, 1); 
	    JSpinner spinner2 = new JSpinner(model2); */
	    propertiesPanel1.add(restockThresholdLabel1);
	    //propertiesPanel1.add(spinner2);
	    JTextField restockThresholdField1 = new JTextField(70);
	    propertiesPanel1.add(restockThresholdField1);

	    JLabel restockAmountLabel1 = new JLabel("Restock Amount: ");
	    propertiesPanel1.add(restockAmountLabel1);
	    /*SpinnerModel model3 = new SpinnerNumberModel(10, 0, 50, 1); 
	    JSpinner spinner3 = new JSpinner(model3);
	    propertiesPanel1.add(spinner3); */
	    JTextField restockAmountField1 = new JTextField(70);
	    propertiesPanel1.add(restockAmountField1);
	    
	    jPanelSecond.add(propertiesPanel1);
	   
	    
		JPanel bottomPanel1 = new JPanel();
		bottomPanel1.setLayout(new GridLayout(1,3));

		JButton delete1 = new JButton("Delete"); 
		JButton edit1 = new JButton("Edit");
		JButton add1 = new JButton("Add"); 
		
		bottomPanel1.add(delete1);
		bottomPanel1.add(edit1);
		bottomPanel1.add(add1);
	    
	    jPanelSecond.add(bottomPanel1);


	    
	    
	    
	    
 
		AddListener AddListenerA = new AddListener(add1, nameField1, descriptionField1, priceField1, restockThresholdField1, restockAmountField1, table1, server);
		add1.addActionListener(AddListenerA);
		nameField1.addActionListener(AddListenerA);
		descriptionField1.addActionListener(AddListenerA);
		priceField1.addActionListener(AddListenerA);
		restockThresholdField1.addActionListener(AddListenerA);
		restockAmountField1.addActionListener(AddListenerA);

		
		DeleteListener DeleteListenerA = new DeleteListener(delete1, table1, server, dishes);
		delete1.addActionListener(DeleteListenerA);
		
		
		
		EditListener EditListenerA = new EditListener(edit1, table1, server, dishes, ingredients);
		edit1.addActionListener(EditListenerA);

	    
	    
	    
	    jPanelThird.setLayout(new BoxLayout(jPanelThird, BoxLayout.Y_AXIS));
	    jTabbedPane.addTab("Ingredients", jPanelThird);

	    List<Ingredient> ingredients1 = server.getIngredients();
	    String[] columnNames2 = {"Name","Units", "Supplier", "Restock Threshold", "Restock Amount"};
	    
        DefaultTableModel model2 = new DefaultTableModel(columnNames2, 0);
        JTable table2 = new JTable(model2);
        for (Ingredient ingredient : ingredients1) {
            model2.addRow(new Object[] {ingredient.getName(), ingredient.getUnit(), ingredient.getSupplier(), ingredient.getRestockThreshold(), ingredient.getRestockAmount()});
        }


        jPanelThird.add(new JScrollPane(table2));

        JPanel propertiesPanel2 = new JPanel();
        propertiesPanel2.setLayout(new GridLayout(8,2));

	    JLabel nameLabel2 = new JLabel("Name: ");
	    JTextField nameField2 = new JTextField(70);
	    propertiesPanel2.add(nameLabel2);
	    propertiesPanel2.add(nameField2);
	    
	    JLabel unitsLabel2 = new JLabel("Units: ");
	    propertiesPanel2.add(unitsLabel2);
	    JTextField unitsField2 = new JTextField(70);
	    propertiesPanel2.add(unitsField2);
	    
	    /*SpinnerModel model4 = new SpinnerNumberModel(10, 0, 50, 1); 
	    JSpinner spinner4 = new JSpinner(model4);
	    propertiesPanel2.add(spinner4); */

	    JLabel supplierLabel2 = new JLabel("Supplier: ");
	    
	    propertiesPanel2.add(supplierLabel2);
	    
        
        List<Supplier> suppliers1 = server.getSuppliers();
        
        DefaultComboBoxModel modelComboBox = new DefaultComboBoxModel(suppliers1.toArray());
        JComboBox<String> suppliersComboBox = new JComboBox<String>(modelComboBox);

        /*for(Supplier supplier: suppliers1) {
        	String supplierName = supplier.getName();
        	suppliersComboBox.addItem(supplierName);
        } */
        
        propertiesPanel2.add(suppliersComboBox);
	    
	    JLabel restockThresholdLabel2 = new JLabel("Restock Threshold: ");
	    propertiesPanel2.add(restockThresholdLabel2);
	    JTextField restockThresholdField2 = new JTextField(70);
	    propertiesPanel2.add(restockThresholdField2);
	    /*SpinnerModel model5 = new SpinnerNumberModel(10, 0, 50, 1); 
	    JSpinner spinner5 = new JSpinner(model5);
	    propertiesPanel2.add(spinner5); */
	    
	    JLabel restockAmountLabel2 = new JLabel("Restock Amount: ");
	    propertiesPanel2.add(restockAmountLabel2);
	    JTextField restockAmountField2 = new JTextField(70);
	    propertiesPanel2.add(restockAmountField2);
	    /*SpinnerModel model6 = new SpinnerNumberModel(10, 0, 50, 1); 
	    JSpinner spinner6 = new JSpinner(model6);
	    propertiesPanel2.add(spinner6); */
	    
	    jPanelThird.add(propertiesPanel2);
	    
		JPanel bottomPanel2 = new JPanel();
		bottomPanel2.setLayout(new GridLayout(1,3));

		JButton delete2 = new JButton("Delete"); 
		JButton edit2 = new JButton("Edit");
		JButton add2 = new JButton("Add"); 
		
		bottomPanel2.add(delete2);
		bottomPanel2.add(edit2);
		bottomPanel2.add(add2);
	    jPanelThird.add(bottomPanel2);
	    
		AddListener2 AddListenerB = new AddListener2(add2, nameField2, unitsField2, suppliersComboBox, restockThresholdField2, restockAmountField2, table2, server);
		add2.addActionListener(AddListenerB);
		nameField2.addActionListener(AddListenerB);
		unitsField2.addActionListener(AddListenerB);
		suppliersComboBox.addActionListener(AddListenerB);
		restockThresholdField2.addActionListener(AddListenerB);
		restockAmountField2.addActionListener(AddListenerB);
		
		DeleteListener2 DeleteListenerB = new DeleteListener2(delete2, table2, server, ingredients);
		delete2.addActionListener(DeleteListenerB);
	    
		EditListener2 EditListenerB = new EditListener2(edit2, table2, server, ingredients);
		edit2.addActionListener(EditListenerB);
	    

		
		
		
		
		
		
	    
	    jPanelFourth.setLayout(new BoxLayout(jPanelFourth, BoxLayout.Y_AXIS));
	    jTabbedPane.addTab("Suppliers", jPanelFourth);

        List<Supplier> suppliers = server.getSuppliers();
	    String[] columnNames3 = {"Name","Postcode", "Distance"};
	    
        DefaultTableModel model3 = new DefaultTableModel(columnNames3, 0);
        JTable table3 = new JTable(model3);
        for (Supplier supplier:suppliers) {
            model3.addRow(new Object[] {supplier.getName(), supplier.getPostcode(), supplier.getDistance()});
        }


        jPanelFourth.add(new JScrollPane(table3));
 
        JPanel propertiesPanel3 = new JPanel();
        propertiesPanel3.setLayout(new GridLayout(8,2));

	    JLabel nameLabel3 = new JLabel("Name: ");
	    JTextField nameField3 = new JTextField(70);
	    propertiesPanel3.add(nameLabel3);
	    propertiesPanel3.add(nameField3);
	    
	    JLabel postCodeLabel3 = new JLabel("Postcode: ");
	    //JTextField postCodeField3 = new JTextField(70);
	    propertiesPanel3.add(postCodeLabel3);
	    
	    
		List<Postcode> postcodes1 = server.getPostcodes();
		DefaultComboBoxModel modelComboBox1 = new DefaultComboBoxModel(postcodes1.toArray());
		JComboBox<String> postcodesComboBox = new JComboBox<String>(modelComboBox1);
		
	    server.notifyUpdate();

        //postcodesComboBox.addItem(postcode);
     
        
        /*for(Postcode postcode: postcodes1) {
        	String postcodeName = postcode.getName();
        	postcodesComboBox.addItem(postcodeName);
        } */
        propertiesPanel3.add(postcodesComboBox);

	    JLabel distanceLabel3 = new JLabel("Distance: ");
	    JTextField distanceField3 = new JTextField(70);
	    propertiesPanel3.add(distanceLabel3);
	    propertiesPanel3.add(distanceField3);
	    /*SpinnerModel model7 = new SpinnerNumberModel(10, 0, 50, 1); 
	    JSpinner spinner7 = new JSpinner(model7);
	    propertiesPanel3.add(spinner7);  */
	    
	    JLabel label1 = new JLabel("");
	    propertiesPanel3.add(label1);
	    
	    JLabel label2 = new JLabel("");
	    propertiesPanel3.add(label2);
	    
	    JLabel label3 = new JLabel("");
	    propertiesPanel3.add(label3);
	    
	    JLabel label4 = new JLabel("");
	    propertiesPanel3.add(label4);
	    
	    jPanelFourth.add(propertiesPanel3);
	    
		JPanel bottomPanel3 = new JPanel();
		bottomPanel3.setLayout(new GridLayout(1,3));

		JButton delete3 = new JButton("Delete"); 
		JButton edit3 = new JButton("Edit");
		JButton add3 = new JButton("Add"); 
		
		bottomPanel3.add(delete3);
		bottomPanel3.add(edit3);
		bottomPanel3.add(add3);
	    jPanelFourth.add(bottomPanel3);
	    
		AddListener3 AddListenerC = new AddListener3(add3, nameField3, suppliersComboBox, postcodesComboBox,  distanceField3, table3, server);
		
		add3.addActionListener(AddListenerC);
		nameField3.addActionListener(AddListenerC);
		suppliersComboBox.addActionListener(AddListenerC);
		distanceField3.addActionListener(AddListenerC);
		postcodesComboBox.addActionListener(AddListenerC);
	    
		DeleteListener3 DeleteListenerC = new DeleteListener3(delete3,table3,server,suppliers, suppliersComboBox);
		delete3.addActionListener(DeleteListenerC);


		
		
		
		
	    
	    jPanelFifth.setLayout(new BoxLayout(jPanelFifth, BoxLayout.Y_AXIS));
	    jTabbedPane.addTab("Staff", jPanelFifth);
  
	    
	    List<Staff> staffs = server.getStaff();
	    String[] columnNames4 = {"Name","Status", "Fatigue"};
	    
        DefaultTableModel model4 = new DefaultTableModel(columnNames4, 0);
        JTable table4 = new JTable(model4);
        for (Staff staff:staffs) {
            model4.addRow(new Object[] {staff.getName(), mockServer.getStaffStatus(staff), staff.getFatigue()});
        }

        jPanelFifth.add(new JScrollPane(table4));
 
        JPanel propertiesPanel4 = new JPanel();
        propertiesPanel4.setLayout(new GridLayout(8,2));

	    JLabel nameLabel4 = new JLabel("Name: ");
	    JTextField nameField4 = new JTextField(70);
	    propertiesPanel4.add(nameLabel4);
	    propertiesPanel4.add(nameField4);
	    
	    JLabel statusLabel4 = new JLabel("Status: ");
	    JTextField statusField4 = new JTextField(70);
	    propertiesPanel4.add(statusLabel4);
	    propertiesPanel4.add(statusField4);

	    JLabel fatigueLabel4 = new JLabel("Fatigue: ");
	    JTextField fatigueField4 = new JTextField(70);
	    propertiesPanel4.add(fatigueLabel4);
	    propertiesPanel4.add(fatigueField4);
	    
	    
	    JLabel label5 = new JLabel("");
	    propertiesPanel4.add(label5);
	    
	    JLabel label6 = new JLabel("");
	    propertiesPanel4.add(label6);
	    
	    JLabel label7 = new JLabel("");
	    propertiesPanel4.add(label7);
	    
	    JLabel label8 = new JLabel("");
	    propertiesPanel4.add(label8);
	    
	    jPanelFifth.add(propertiesPanel4);
	    
		JPanel bottomPanel4 = new JPanel();
		bottomPanel4.setLayout(new GridLayout(1,3));

		JButton delete4 = new JButton("Delete"); 
		JButton edit4 = new JButton("Edit");
		JButton add4 = new JButton("Add"); 
		
		bottomPanel4.add(delete4);
		bottomPanel4.add(edit4);
		bottomPanel4.add(add4);
	    jPanelFifth.add(bottomPanel4);
	    
		AddListener4 AddListenerD = new AddListener4(add4, nameField4, statusField4,  fatigueField4, table4, server);

		add4.addActionListener(AddListenerD);
		nameField4.addActionListener(AddListenerD);
		statusField4.addActionListener(AddListenerD);
		fatigueField4.addActionListener(AddListenerD);
	    

		DeleteListener4 DeleteListenerD = new DeleteListener4(delete4,table4,server,staffs);
		delete4.addActionListener(DeleteListenerD);
	    
	    
	   
		
	
	    jPanelSixth.setLayout(new BoxLayout(jPanelSixth, BoxLayout.Y_AXIS));
	    jTabbedPane.addTab("Drones", jPanelSixth);
	    
	    List <Drone> drones = server.getDrones();
	    String[] columnNames5 = {"Name", "Speed","Progress", "Capacity", "Battery", "Status", "Source", "Destination"};
        DefaultTableModel model5 = new DefaultTableModel(columnNames5, 0);
        JTable table5 = new JTable(model5);
        for (Drone drone:drones) {
            model5.addRow(new Object[] {drone.getName(), drone.getSpeed(), drone.getProgress(), drone.getCapacity(), drone.getBattery(), drone.getStatus(), mockServer.getDroneSource(drone), mockServer.getDroneDestination(drone)});
        }
        jPanelSixth.add(new JScrollPane(table5));
 
        JPanel propertiesPanel5 = new JPanel();
        propertiesPanel5.setLayout(new GridLayout(8,2));

	    JLabel nameLabel5 = new JLabel("Name: ");
	    JTextField nameField5 = new JTextField(70);
	    propertiesPanel5.add(nameLabel5);
	    propertiesPanel5.add(nameField5);
	    
	    JLabel speedLabel5 = new JLabel("Speed: ");
	    JTextField speedField5 = new JTextField(70);
	    propertiesPanel5.add(speedLabel5);
	    propertiesPanel5.add(speedField5);

	    JLabel progressLabel5 = new JLabel("Progress: ");
	    JTextField progressField5 = new JTextField(70);
	    propertiesPanel5.add(progressLabel5);
	    propertiesPanel5.add(progressField5);
	    
	    JLabel capacityLabel5 = new JLabel("Capacity: ");
	    JTextField capacityField5 = new JTextField(70);
	    propertiesPanel5.add(capacityLabel5);
	    propertiesPanel5.add(capacityField5);
	    
	    JLabel batteryStatusLabel5 = new JLabel("Battery Status: ");
	    JTextField batteryStatusField5 = new JTextField(70);
	    propertiesPanel5.add(batteryStatusLabel5);
	    propertiesPanel5.add(batteryStatusField5);
	    
	    JLabel sourceLabel5 = new JLabel("Source: ");
	    JTextField sourceField5 = new JTextField(70);
	    propertiesPanel5.add(sourceLabel5);
	    propertiesPanel5.add(sourceField5);
	    
	    JLabel destinationLabel5 = new JLabel("Destination: ");
	    JTextField destinationField5 = new JTextField(70);
	    propertiesPanel5.add(destinationLabel5);
	    propertiesPanel5.add(destinationField5);
	    
	    jPanelSixth.add(propertiesPanel5);
	    
		JPanel bottomPanel5 = new JPanel();
		bottomPanel5.setLayout(new GridLayout(1,3));

		JButton delete5 = new JButton("Delete"); 
		JButton edit5 = new JButton("Edit");
		JButton add5 = new JButton("Add"); 
		
		bottomPanel5.add(delete5);
		bottomPanel5.add(edit5);
		bottomPanel5.add(add5);
	    jPanelSixth.add(bottomPanel5); 
	    
		AddListener5 AddListenerE = new AddListener5(add5, nameField5, speedField5,  progressField5, capacityField5, batteryStatusField5, sourceField5, destinationField5, table5, server);

		add5.addActionListener(AddListenerE);
		nameField5.addActionListener(AddListenerE);
		speedField5.addActionListener(AddListenerE);
		progressField5.addActionListener(AddListenerE);
		capacityField5.addActionListener(AddListenerE);
		batteryStatusField5.addActionListener(AddListenerE);
		sourceField5.addActionListener(AddListenerE);
		destinationField5.addActionListener(AddListenerE);
	    

		DeleteListener5 DeleteListenerE = new DeleteListener5(delete5,table5,server,drones);
		delete5.addActionListener(DeleteListenerE);
	    
	    
	    
	    
	    
	    jPanelSeventh.setLayout(new BoxLayout(jPanelSeventh, BoxLayout.Y_AXIS));
	    jTabbedPane.addTab("Users", jPanelSeventh);
	    
	    String[] columnNames6 = {"Name","Address","Postcode"};
		Object[][] data6 = {{"User1", "Address1", "SO16 3RD"},{"User2", "Address2", "SO16 3UF"}, {"User3", "Address3", "SO17 ITJ"}};
		
	    JTable table6 = new JTable(data6, columnNames6);

        jPanelSeventh.add(new JScrollPane(table6));
 
        JPanel propertiesPanel6 = new JPanel();
        propertiesPanel6.setLayout(new GridLayout(8,2));

	    JLabel nameLabel6 = new JLabel("Name: ");
	    JTextField nameField6 = new JTextField(70);
	    propertiesPanel6.add(nameLabel6);
	    propertiesPanel6.add(nameField6);
	    
	    JLabel passwordLabel6 = new JLabel("Password: ");
	    JTextField passwordField6 = new JTextField(70);
	    propertiesPanel6.add(passwordLabel6);
	    propertiesPanel6.add(passwordField6);

	    JLabel addressLabel6 = new JLabel("Address: ");
	    JTextField addressField6 = new JTextField(70);
	    propertiesPanel6.add(addressLabel6);
	    propertiesPanel6.add(addressField6);
	    
	    JLabel postCodeLabel6 = new JLabel("Postcode: ");
	    JTextField postCodeField6 = new JTextField(70);
	    propertiesPanel6.add(postCodeLabel6);
	    propertiesPanel6.add(postCodeField6);

	    JLabel label20 = new JLabel("");
	    propertiesPanel6.add(label20);

	    jPanelSeventh.add(propertiesPanel6);
	    
		JPanel bottomPanel6 = new JPanel();
		bottomPanel6.setLayout(new GridLayout(1,3));

		JButton delete6 = new JButton("Delete"); 
		JButton edit6 = new JButton("Edit");
		JButton add6 = new JButton("Add"); 
		
		bottomPanel6.add(delete6);
		bottomPanel6.add(edit6);
		bottomPanel6.add(add6);
	    jPanelSeventh.add(bottomPanel6);
	    
	    
	    
	    
	    
	    
	    jPanelEighth.setLayout(new BoxLayout(jPanelEighth, BoxLayout.Y_AXIS));
	    jTabbedPane.addTab("Postcodes", jPanelEighth);
	    
		
		List<Postcode> postcodes = server.getPostcodes();
	    String[] columnNames7 = {"Postcode", "Distance (km)", "Longitude", "Latitude"};
	    
        DefaultTableModel model7 = new DefaultTableModel(columnNames7, 0);
        JTable table7 = new JTable(model7);
    	Postcode restaurantPostcode = server.getRestaurantPostcode();
    	System.out.println(restaurantPostcode.getName());
    	

    	
        for (Postcode postcode : postcodes) {

        Map<String,Double> latLong = postcode.getLatLong();
      	Double longitude = latLong.get("lon");//postcode.getLongitude();
      	Double latitude = latLong.get("lat");//postcode.getLatitude();
  	
    		
    	model7.addRow(new Object[] {postcode.getName(), postcode.getDistance(), longitude, latitude});
        }

        jPanelEighth.add(new JScrollPane(table7));
 
        JPanel propertiesPanel7 = new JPanel();
        propertiesPanel7.setLayout(new GridLayout(8,2));

	    JLabel nameLabel7 = new JLabel("Postcode: ");
	    JTextField nameField7 = new JTextField(70);
	    propertiesPanel7.add(nameLabel7);
	    propertiesPanel7.add(nameField7);
	    
	    JLabel distanceLabel7 = new JLabel("Distance: ");
	    JTextField distanceField7 = new JTextField(70);
	    propertiesPanel7.add(distanceLabel7);
	    propertiesPanel7.add(distanceField7);

	    JLabel distanceLabel8 = new JLabel("");
	    propertiesPanel7.add(distanceLabel8);
	    
	    JLabel label9 = new JLabel("");
	    propertiesPanel7.add(label9);

	    JLabel label10 = new JLabel("");
	    propertiesPanel7.add(label10);
	    
	    JLabel label11 = new JLabel("");
	    propertiesPanel7.add(label11);
	    
	    JLabel label12 = new JLabel("");
	    propertiesPanel7.add(label12);
	    
	    JLabel label13 = new JLabel("");
	    propertiesPanel7.add(label13);
	    
	    JLabel label14 = new JLabel("");
	    propertiesPanel7.add(label14);
	   
	    jPanelEighth.add(propertiesPanel7);
	    
		JPanel bottomPanel7 = new JPanel();
		bottomPanel7.setLayout(new GridLayout(1,3));

		JButton delete7 = new JButton("Delete"); 
		JButton edit7 = new JButton("Edit");
		JButton add7 = new JButton("Add"); 
		
		bottomPanel7.add(delete7);
		bottomPanel7.add(edit7);
		bottomPanel7.add(add7);
	    jPanelEighth.add(bottomPanel7);
	    
		AddListener7 AddListenerG = new AddListener7(add7, nameField7, distanceField7, table7, postcodesComboBox, server);
		add7.addActionListener(AddListenerG);
		nameField7.addActionListener(AddListenerG);
		distanceField7.addActionListener(AddListenerG);
		postcodesComboBox.addActionListener(AddListenerG);
	    

		DeleteListener7 DeleteListenerG = new DeleteListener7 (delete7, table7, server, postcodes, postcodesComboBox);
		delete7.addActionListener(DeleteListenerG);
	    
	    
	    

	    
		/*protected void calculateDistance(Restaurant restaurant) {
			//This function needs implementing
			Postcode destination = restaurant.getLocation();
			this.distance = Integer.valueOf(0);
		}
		
		protected void calculateLatLong() {
			//This function needs implementing
			this.latLong = new HashMap<String,Double>();
			latLong.put("lat", 0d);
			latLong.put("lon", 0d);
			this.distance = new Integer(0);
		}*/
	   

	    
	    
	    
	    jPanelNineth.setLayout(new GridLayout());
	    jTabbedPane.addTab("Configuration", jPanelNineth);
		
		panel.add(jTabbedPane, BorderLayout.NORTH);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
				
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE); 
	}




}
