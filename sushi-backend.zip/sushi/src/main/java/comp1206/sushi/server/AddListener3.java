package comp1206.sushi.server;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Postcode;
import comp1206.sushi.common.Supplier;
import comp1206.sushi.server.ServerWindow;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;

import java.awt.event.*;
import java.util.List;

	class AddListener3 implements ActionListener {

	    JButton b1;
	    JTextField t1;
	    JComboBox<String>t3;
	    JComboBox<String>t2;
	    JTextField t4;
	    JTable table1;
	    ServerInterface server;
	    
	    String supplierName;
	    boolean check = false;

		
	    public AddListener3(JButton b1, JTextField t1, JComboBox<String>t2, JComboBox<String>t3, JTextField t4, JTable table1, ServerInterface server){
			this.b1 = b1;
			this.t1 = t1;
			this.t2 = t2;
			this.t3 = t3;
			this.t4 = t4;
			this.table1 = table1;
			this.server = server;
	    }

	    	
	    public void actionPerformed(ActionEvent e){	
	    	List<Supplier> suppliers = server.getSuppliers();
	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();
	    	String text4 = t4.getText();
	    	
	    	

	    	
	    	if(e.getSource() == b1){
		    	for(Supplier supplier: suppliers) {
	            	if(t1.getText().equals(supplier.getName())) {
	            		check = true;
		    	    	JFrame frame = new JFrame("Invalid data");
		    	    	
		    			//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			            frame.setSize(350, 100);
			            JPanel panel1 = new JPanel();
			            JLabel label = new JLabel("Data entered is invalid. This supplier is already in the system.");
			            //frame.add(panel1);
			            panel1.add(label);
			            frame.add(panel1);
			            frame.setVisible(true);
			            frame.setLocationRelativeTo(null);
			            
			            
	            	}
	            	//if new supplier added
	            	/*else {
	            		check = false;
	            	}*/
	            	
	            }
		    	
		    	
		    	
	    		if(t1.getText().equals("")|| t4.getText().equals("")|| t3.getSelectedItem().equals("")) {

	    	    	JFrame frame = new JFrame("Invalid data");
		            frame.setSize(350, 100);
		            JPanel panel1 = new JPanel();
		            JLabel label = new JLabel("Data entered is invalid. Please enter all fields.");
		            panel1.add(label);
		            frame.add(panel1);
		            frame.setVisible(true);
		            frame.setLocationRelativeTo(null);
	    		}

		    		
			   else {
				   if(check == false) {
					   if (isNumeric(text4)) {
						   model.addRow(new Object[]{t1.getText(), t3.getSelectedItem(), t4.getText()}); 	  
						   server.addSupplier(t1.getText(), (Postcode) t3.getSelectedItem());
						   t2.addItem(t1.getText());
					   }
					   else {
			    	    	JFrame frame = new JFrame("Invalid data");
				            frame.setSize(450, 100);
				            JPanel panel1 = new JPanel();
				            JLabel label = new JLabel("Data entered is invalid. The distance field must be filled with an integer value.");
				            panel1.add(label);
				            frame.add(panel1);
				            frame.setVisible(true);
				            frame.setLocationRelativeTo(null); 
					   }
				   }
			   }
	    		
	    		check = false;
		    }
}
	    
	    public static boolean isNumeric(String strNum) {
	        try {
	            double d = Double.parseDouble(strNum);
	        } catch (NumberFormatException | NullPointerException nfe) {
	            return false;
	        }
	        return true;
	    }
 

	   
	    	
	        
}

	    
