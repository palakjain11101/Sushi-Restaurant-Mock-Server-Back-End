package comp1206.sushi.server;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Ingredient;

import java.awt.event.*;
import java.util.List;
import java.util.Map;

	class AddListener1 implements ActionListener {

	    JButton a;
	    JButton d;
	    JComboBox<String> ingredientsComboBox;
	    JTextField ingredientNumberField;
	    List<Dish> dishes;
	    ServerInterface server;
	    JTable table;
	    JTable table1;
	    Map<Ingredient, Number> recipe;
	    List<Ingredient> ingredients;


	    public AddListener1(JButton a, JButton d, JComboBox<String> ingredientsComboBox, JTextField ingredientNumberField, ServerInterface server, List<Dish> dishes, JTable table, JTable table1, Map<Ingredient, Number> recipe, List<Ingredient> ingredients ) {
			this.a = a;
			this.d = d;
			this.ingredientsComboBox = ingredientsComboBox;
			this.ingredientNumberField = ingredientNumberField;
			this.server = server;
			this.dishes = dishes;
			this.table = table;
			this.table1 = table1;
			this.recipe = recipe;
			this.ingredients = ingredients;
	    }


	    public void actionPerformed(ActionEvent e){	
	    	DefaultTableModel model = (DefaultTableModel) table.getModel();
	    	DefaultTableModel model1 = (DefaultTableModel) table1.getModel();
            List<Dish> dishes = server.getDishes();
            int column = 0;
            int row = table.getSelectedRow();
            String dishName = model.getValueAt(row, column).toString();
            
            Dish dish = findDishByName(dishes, dishName);
		

	    	if(e.getSource() == a){
	    	   // if (table.getSelectedRow() != -1) {
	    	    //public void addIngredientToDish(Dish dish, Ingredient ingredient, Number quantity)         
	    	    	model1.addRow(new Object[]{ingredientsComboBox.getSelectedItem(), ingredientNumberField.getText()}); 
		    	    server.addIngredientToDish(dish,(Ingredient)ingredientsComboBox.getSelectedItem(),Integer.valueOf(ingredientNumberField.getText()));
	    	    //server.notifyUpdate();
	    	   // }
	    	}
	   

	    	    
	    	
	    	else if(e.getSource() == d) {

	    		server.removeIngredientFromDish(dish,(Ingredient)ingredientsComboBox.getSelectedItem());
	    	    
	    		model1.removeRow(table1.getSelectedRow());
	    		
	    	}
	    }
	    	
	  
	
		 private static Dish findDishByName(List<Dish> dishes, String dishName)
	     {
	        for(Dish dish: dishes) {
	        	if(dishName.equals(dish.getName())) {
	        		return dish;
	        	}
	        }
	        
	        throw new RuntimeException("No dish with given name");
	     }
		    	

	    	

}