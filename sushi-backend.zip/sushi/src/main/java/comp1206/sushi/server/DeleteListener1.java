package comp1206.sushi.server;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import comp1206.sushi.common.Dish;
import comp1206.sushi.server.ServerInterface.UnableToDeleteException;
import java.awt.event.*;
import java.util.List;

	class DeleteListener1 implements ActionListener {

	    JButton b1;
	    JTable table1;
	    List<Dish> dishes;
	    ServerInterface server;

	    public DeleteListener1(JButton b1,JTable table1,ServerInterface server, List<Dish> dishes){
			this.b1 = b1;
			this.table1 = table1;
			this.server = server;
			this.dishes = dishes;
	    }

	    
	    public void actionPerformed(ActionEvent e) {

	    	DefaultTableModel model = (DefaultTableModel) table1.getModel();

	        if (table1.getSelectedRow() != -1) {

	            List<Dish> dishes = server.getDishes();
	            int column = 0;
	            int row = table1.getSelectedRow();
	            String dishName = model.getValueAt(row, column).toString();
	            
	            Dish dish = findDishByName(dishes, dishName);

        		try {
        			server.removeDish(dish);
				} catch (UnableToDeleteException e1) {
					e1.printStackTrace();
				}
        		
	            model.removeRow(table1.getSelectedRow()); 
	        }
	     }
	        
	     private static Dish findDishByName(List<Dish> dishes, String dishName)
	     {
            for(Dish dish: dishes) {
            	if(dishName.equals(dish.getName())) {
            		return dish;
            	}
            }
            
            throw new RuntimeException("No dish with given name");
	     }
    }
